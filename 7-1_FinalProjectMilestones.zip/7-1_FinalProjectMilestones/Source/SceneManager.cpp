///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// I'm loading each mesh I'll need - only need to do this once regardless of how many times I draw them

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();

	// I'm loading the textures for each surface type in the scene
	CreateGLTexture("textures/grass_texture.jpg", "grass");
	CreateGLTexture("textures/pavement_texture.jpg", "pavement");
	CreateGLTexture("textures/tree_bark.jpg", "bark");
	CreateGLTexture("textures/tree_leaves.jpg", "leaves");

	// sending all loaded textures to the GPU so they're ready to use
	BindGLTextures();

	// I'm defining materials here so each object responds to light differently

	// I set grass to fully matte because grass doesn't reflect light like a polished surface
	OBJECT_MATERIAL grassMat;
	grassMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f); 
	grassMat.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	grassMat.shininess = 1.0f;
	grassMat.tag = "grass";
	m_objectMaterials.push_back(grassMat);

	// I gave pavement a slight specular so it catches light the way hard stone would
	OBJECT_MATERIAL pavementMat;
	pavementMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f); 
	pavementMat.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	pavementMat.shininess = 16.0f;
	pavementMat.tag = "pavement";
	m_objectMaterials.push_back(pavementMat);

	// I kept bark very rough with almost no shine since tree bark is a dry, uneven surface
	OBJECT_MATERIAL barkMat;
	barkMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f); 
	barkMat.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	barkMat.shininess = 4.0f;
	barkMat.tag = "bark";
	m_objectMaterials.push_back(barkMat);

	// I gave leaves a low shininess value because foliage is soft and doesn't produce shiny highlights
	OBJECT_MATERIAL leavesMat;
	leavesMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f); 
	leavesMat.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	leavesMat.shininess = 2.0f;
	leavesMat.tag = "leaves";
	m_objectMaterials.push_back(leavesMat);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// I'm declaring the transformation variables I'll reuse for every shape
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// I'm enabling lighting here and setting up all three light sources before drawing anything
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setBoolValue(g_UseLightingName, true);
		
		// I set up a directional light to act like the sun - angled slightly to cast natural shadows
		m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(0.3f, -1.0f, -0.3f));
		m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.4f, 0.42f, 0.45f)); // I pulled the ambient back so nothing looks overexposed
		m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.8f, 0.76f, 0.68f)); // I gave it a warm tone to feel like afternoon sunlight
		m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.15f, 0.15f, 0.15f)); 
		m_pShaderManager->setBoolValue("directionalLight.bActive", true);

		// I placed a point light high up on the left to simulate open sky filling in the shadows
		m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(-5.0f, 8.0f, 5.0f));
		m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.1f, 0.1f, 0.1f)); 
		m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.35f, 0.35f, 0.35f)); // I kept this dim so it only softens shadows, not competes with the sun
		m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.05f, 0.05f, 0.05f));
		m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

		// I added a golden spotlight aimed at the topiary - this is my colored light and it gives the tree a warm garden glow
		m_pShaderManager->setVec3Value("spotLight.position", glm::vec3(0.0f, 8.0f, 5.0f));
		m_pShaderManager->setVec3Value("spotLight.direction", glm::vec3(0.0f, -1.0f, -0.5f));
		m_pShaderManager->setFloatValue("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
		m_pShaderManager->setFloatValue("spotLight.outerCutOff", glm::cos(glm::radians(17.5f)));
		m_pShaderManager->setFloatValue("spotLight.constant", 1.0f);
		m_pShaderManager->setFloatValue("spotLight.linear", 0.09f);
		m_pShaderManager->setFloatValue("spotLight.quadratic", 0.032f);
		m_pShaderManager->setVec3Value("spotLight.ambient", glm::vec3(0.0f, 0.0f, 0.0f));
		m_pShaderManager->setVec3Value("spotLight.diffuse", glm::vec3(1.0f, 0.75f, 0.2f)); // amber/golden tint
		m_pShaderManager->setVec3Value("spotLight.specular", glm::vec3(1.0f, 0.8f, 0.3f)); // golden highlight on the topiary surface
		m_pShaderManager->setBoolValue("spotLight.bActive", true);
	}

	// I'm drawing everything from here down, reusing the same transformation pattern for each shape

	// I scaled the ground plane wide and flat to cover the scene floor
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// I centered the ground at the origin
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// I used pavement texture here and reduced the tiling so the stones look a natural size
	SetShaderTexture("pavement");
	SetTextureUVScale(4.0f, 2.0f);
	SetShaderMaterial("pavement");

	m_basicMeshes->DrawPlaneMesh();
	/***************************************************************/
	// I shortened the trunk height so the tree top starts closer to the ground, like the reference
	scaleXYZ = glm::vec3(0.5f, 1.0f, 0.5f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("bark");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("bark");
	m_basicMeshes->DrawCylinderMesh();

	// I added a small cone at the base to fake a root flare - it sits inside the hedge ring
	scaleXYZ = glm::vec3(0.8f, 0.4f, 0.8f); 
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f); 
	
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("bark"); 
	SetShaderMaterial("bark");
	m_basicMeshes->DrawConeMesh();

	// I used five stacked cones to build up the spiral topiary shape
	// each layer gets narrower and sits higher to create the tiered effect

	// Layer 1 - widest at the bottom, this is where the topiary starts
	scaleXYZ = glm::vec3(2.5f, 2.0f, 2.5f);
	positionXYZ = glm::vec3(0.0f, 1.0f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("leaves"); 
	SetTextureUVScale(0.7f, 0.7f); // I scaled the UV down so the leaf detail isn't too small
	SetShaderMaterial("leaves");
	m_basicMeshes->DrawConeMesh();

	// Layer 2 - slightly smaller and moved up
	scaleXYZ = glm::vec3(2.0f, 2.0f, 2.0f);
	positionXYZ = glm::vec3(0.0f, 2.2f, 0.0f); 
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawConeMesh();

	// Layer 3 - continuing to taper
	scaleXYZ = glm::vec3(1.5f, 1.8f, 1.5f);
	positionXYZ = glm::vec3(0.0f, 3.4f, 0.0f); 
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawConeMesh();

	// Layer 4 - getting close to the tip now
	scaleXYZ = glm::vec3(1.0f, 1.5f, 1.0f);
	positionXYZ = glm::vec3(0.0f, 4.4f, 0.0f); 
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawConeMesh();

	// Layer 5 - the topmost point, narrow and tall to finish the spiral shape
	scaleXYZ = glm::vec3(0.5f, 1.2f, 0.5f);
	positionXYZ = glm::vec3(0.0f, 5.2f, 0.0f); 
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawConeMesh();

	// I dropped a sphere in the middle of the foliage to hint at the inner volume of the tree
	scaleXYZ = glm::vec3(1.4f, 1.4f, 1.4f);
	positionXYZ = glm::vec3(0.0f, 2.5f, 0.0f); 
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawSphereMesh();

	// I built the hedge ring using three stacked torus shapes
	// flattening them vertically and rotating each one slightly creates a denser wall-like look

	// bottom ring - I placed this just above ground level
	scaleXYZ = glm::vec3(2.2f, 1.0f, 2.2f);
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.2f, 0.0f); 

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("grass"); 
	SetTextureUVScale(6.0f, 1.0f); // I increased U tiling here so the grass flows around the ring without stretching
	SetShaderMaterial("grass");
	m_basicMeshes->DrawTorusMesh();

	// middle ring - I rotated it 15 degrees so it doesn't overlap the base ring identically
	scaleXYZ = glm::vec3(2.2f, 1.0f, 2.2f); 
	positionXYZ = glm::vec3(0.0f, 0.5f, 0.0f);
	YrotationDegrees = 15.0f; 
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawTorusMesh();

    // top ring - I rotated it another 15 degrees and scaled it slightly smaller for a tapered look
	scaleXYZ = glm::vec3(2.1f, 1.0f, 2.1f); 
	positionXYZ = glm::vec3(0.0f, 0.8f, 0.0f);
	YrotationDegrees = 30.0f; 
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawTorusMesh();
	// I added three background cones to give the scene depth, like the trees visible behind the topiary in the reference

	// left background tree - I placed this further back and off to the side
	scaleXYZ = glm::vec3(2.0f, 4.5f, 2.0f);
	positionXYZ = glm::vec3(-4.0f, 0.0f, -8.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("grass");
	SetTextureUVScale(1.5f, 1.5f);
	SetShaderMaterial("grass");
	m_basicMeshes->DrawConeMesh();

	// right background tree - I made this mirror the left one
	positionXYZ = glm::vec3(4.0f, 0.0f, -8.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawConeMesh();

	// center background tree - I made this one the tallest since it's directly behind the topiary
	scaleXYZ = glm::vec3(2.5f, 5.0f, 2.5f);
	positionXYZ = glm::vec3(0.0f, 0.0f, -10.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawConeMesh();
}
